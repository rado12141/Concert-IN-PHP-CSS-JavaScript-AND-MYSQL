<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Gym System : By CIT </title>
          <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1" />
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src = "assets/javascript/javascript.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAuvW7q2HpS6oFo_9Yq6aWj2e1RIuIOwEA"> </script>
        <script type="text/javascript" src="assets/javascript/maps.js"></script>
</head>
<body>