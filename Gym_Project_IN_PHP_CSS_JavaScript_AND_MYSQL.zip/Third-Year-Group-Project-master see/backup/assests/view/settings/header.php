<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Settings</title>
          <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1" />
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src = "assets/javascript/javascript.js"></script>
    
    
    
</head>
<body>