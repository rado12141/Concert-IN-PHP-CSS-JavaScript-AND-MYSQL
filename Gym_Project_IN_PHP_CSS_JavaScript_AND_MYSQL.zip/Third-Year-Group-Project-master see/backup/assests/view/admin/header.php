<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1" />
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src = "assets/javascript/javascript.js"></script>
    <link rel="stylesheet" href="assets/javascript/jqueryui/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/calendarstyle.css">
    <script src="assets/javascript/jqueryui/external/jquery/jquery.js"></script>
    <script src="assets/javascript/jqueryui/jquery-ui.min.js"></script>
    <script src="assets/javascript/calendarScript.js"></script>

</head>
