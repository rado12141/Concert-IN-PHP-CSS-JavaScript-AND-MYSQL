<?php 
// comment
	include_once("assets/controller/Controller.php");

	$controller = new Controller();
	$controller->invoke();

?>