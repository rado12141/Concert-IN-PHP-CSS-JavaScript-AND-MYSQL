<?php

include('settings/header.php');
include('settings/index.php');
include('settings/footer.php');

?>
