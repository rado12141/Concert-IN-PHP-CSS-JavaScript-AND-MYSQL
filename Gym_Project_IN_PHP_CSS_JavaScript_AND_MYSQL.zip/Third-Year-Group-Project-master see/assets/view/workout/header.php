<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Profile</title>
        <link rel="stylesheet" href="assets/css/CheatSheet/animations.css">
    
    <link rel='stylesheet' media='screen and (min-width: 640px) and (max-width: 9000px)' href='assets/css/normal/style.css' />
    <link rel='stylesheet' media='screen and (min-width:   0px) and (max-width: 639px)' href='assets/css/mobile/style.css' />

    
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src = "assets/javascript/javascript.js"></script>
    <script src="assets/javascript/charts/highcharts.js"></script>
    	<script src="assets/javascript/chartsjs.js"></script>
    <script src="assets/javascript/charts/exporting.js"></script>
    <script src="assets/javascript/charts/data.js"></script>
    <script src="assets/javascript/charts/cardio.js"></script>
    <script src="assets/javascript/charts/weight.js"></script>
    <script src="assets/javascript/charts/barcharts.js"></script>
    <script src = "assets/api/calendar/calendar.js"></script>
    <script src="https://apis.google.com/js/client.js?onload=handleClientLoad"></script>
    <link rel="stylesheet" href="assets/css/CheatSheet/animations.css">
    
</head>
<body>