<?php

include('admin/header.php');
include('admin/index.php');
include('admin/footer.php');

?>
