<?php

include('viewBooking/header.php');
include('viewBooking/index.php');
include('viewBooking/footer.php');

?>
