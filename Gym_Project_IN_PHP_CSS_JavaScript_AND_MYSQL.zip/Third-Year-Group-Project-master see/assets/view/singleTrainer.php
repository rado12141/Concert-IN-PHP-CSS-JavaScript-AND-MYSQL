<?php

include('singleTrainer/header.php');
include('singleTrainer/index.php');
include('singleTrainer/footer.php');

?>
