![alt text](.github/readme.png "Logo Title Text 1")


## About 

A Gym booking and content management system. Allows gym members to book training sessions. Allows them to enter their training sessions results and more.


## Getting Started

- Install the sql script
- Change the config settings
- Thats it